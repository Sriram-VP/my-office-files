let mobile = document.getElementsByClassName("mob");
let web = document.getElementsByClassName("web");
let iot = document.getElementsByClassName("iot");
let full = document.getElementsByClassName("full");



document.getElementById("demo").innerHTML = "Hello World!";